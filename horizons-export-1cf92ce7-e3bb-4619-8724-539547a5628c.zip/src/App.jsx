import React, { useState } from 'react';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import ServicesSection from '@/components/ServicesSection';
import FaqSection from '@/components/FaqSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';
import ImageModal from '@/components/ImageModal';

const App = () => {
  const [modalImage, setModalImage] = useState(null);

  const menuItems = [
    { id: 'inicio', label: 'Início' },
    { id: 'sobre', label: 'Sobre' },
    { id: 'servicos', label: 'Serviços' },
    { id: 'faq', label: 'FAQ' },
    { id: 'contato', label: 'Contato', isExternal: true, url: 'https://api.whatsapp.com/send?phone=5515981100025' }
  ];

  const openImageModal = (src, alt) => {
    setModalImage({ src, alt });
  };

  const closeImageModal = () => {
    setModalImage(null);
  };

  return (
    <div className="min-h-screen bg-white scroll-smooth">
      <Toaster />
      <Header menuItems={menuItems} />
      <main>
        <HeroSection onImageClick={openImageModal} />
        <AboutSection onImageClick={openImageModal} />
        <ServicesSection />
        <FaqSection />
        <ContactSection />
      </main>
      <Footer />
      {modalImage && (
        <ImageModal
          src={modalImage.src}
          alt={modalImage.alt}
          onClose={closeImageModal}
        />
      )}
    </div>
  );
};

export default App;