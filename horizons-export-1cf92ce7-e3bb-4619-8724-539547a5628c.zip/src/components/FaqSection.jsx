import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqData = [
  {
    question: 'Quais são meus principais direitos como trabalhador?',
    answer: 'Você tem direito a um salário justo e pontual, jornada de trabalho regulamentada, férias anuais remuneradas, décimo terceiro salário, FGTS, seguro-desemprego em caso de demissão involuntária, licenças maternidade e paternidade, além de um ambiente de trabalho seguro e respeitoso, conforme estipulado pela CLT e pela Constituição Federal.'
  },
  {
    question: 'Quais as obrigações fundamentais de um empregador?',
    answer: 'O empregador deve formalizar o vínculo empregatício com o devido registro, efetuar o pagamento dos salários e benefícios em dia, realizar o recolhimento correto dos encargos sociais (INSS, FGTS), fornecer Equipamentos de Proteção Individual (EPIs) quando necessário, garantir um ambiente laboral seguro e saudável, e respeitar integralmente as leis trabalhistas.'
  },
  {
    question: 'Como funciona uma negociação de acordo trabalhista?',
    answer: 'A negociação de acordo é uma via estratégica para resolver pendências trabalhistas de forma mais rápida e amigável, evitando o desgaste de um processo judicial. Nosso papel é analisar minuciosamente seu caso, identificar todos os direitos possivelmente violados, calcular os valores devidos com precisão e, então, conduzir uma negociação firme e técnica com a parte contrária, buscando sempre o acordo mais vantajoso e justo para você.'
  },
  {
    question: 'Como é a atuação do advogado em um processo judicial trabalhista?',
    answer: 'Nossa representação em tribunais começa com uma análise profunda e detalhada do seu caso, seguida da coleta rigorosa de todas as provas e documentos pertinentes. Elaboramos uma petição inicial robusta e estratégica, acompanhamos de perto cada etapa processual, incluindo audiências, e apresentamos defesas e recursos com embasamento técnico, sempre com o objetivo de alcançar o melhor resultado possível para seus interesses.'
  },
  {
    question: 'Em que situações devo procurar um advogado trabalhista?',
    answer: 'É crucial buscar orientação jurídica especializada ao se deparar com situações como: demissão sem justa causa com verbas rescisórias incorretas ou não pagas, coação para pedido de demissão, assédio moral ou sexual no ambiente de trabalho, acidentes de trabalho ou doenças ocupacionais, alterações contratuais lesivas, não pagamento de horas extras, ou qualquer outra circunstância que indique violação dos seus direitos trabalhistas.'
  }
];

const FaqSection = () => {
  const [openFaq, setOpenFaq] = useState(null);

  const sectionVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
  };

  const faqItemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.5,
        ease: "easeOut"
      }
    })
  };

  return (
    <section id="faq" className="section-padding bg-gray-50 overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Dúvidas Comuns Esclarecidas</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Respostas claras e diretas para as principais questões sobre Direito Trabalhista, ajudando você a entender seus direitos.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto space-y-4">
          {faqData.map((faq, index) => (
            <motion.div
              key={index}
              custom={index}
              variants={faqItemVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
              className="bg-white rounded-lg shadow-md overflow-hidden"
            >
              <button
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <h3 className="font-semibold text-gray-900 pr-4">{faq.question}</h3>
                {openFaq === index ? (
                  <ChevronUp className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                )}
              </button>
              <AnimatePresence>
                {openFaq === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-4">
                      <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FaqSection;