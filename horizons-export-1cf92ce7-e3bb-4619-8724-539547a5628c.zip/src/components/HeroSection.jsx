import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const HeroSection = ({ onImageClick }) => {
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const newImageUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/1cf92ce7-e3bb-4619-8724-539547a5628c/0b83134d2ba90f40d8791a6801fea2cb.jpg";
  const newImageAlt = "Dr. João Silva, advogado trabalhista especialista, pronto para defender seus direitos.";


  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1, 
      transition: { staggerChildren: 0.2, delayChildren: 0.1 } 
    },
  };

  const titleVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } },
  };

  const paragraphVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut", delay: 0.2 } },
  };

  const buttonGroupVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut", delay: 0.4 } },
  };
  
  const imageVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.8, ease: "easeOut", delay: 0.3 } },
    hover: { scale: 1.05, transition: { duration: 0.3 } }
  };

  return (
    <section id="inicio" className="pt-16 section-padding bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white relative overflow-hidden">
      <div className="absolute inset-0 pattern-dots opacity-20"></div>
      <motion.div 
        className="container mx-auto px-4 relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <motion.h1 
              variants={titleVariants}
              className="text-4xl md:text-6xl font-bold leading-tight"
            >
              Defesa Incisiva em
              <span className="text-gradient block">Direito Trabalhista</span>
            </motion.h1>
            <motion.p 
              variants={paragraphVariants}
              className="text-xl text-gray-300 leading-relaxed"
            >
              Com mais de 15 anos de experiência, Dr. João Silva é sua maior garantia na defesa intransigente dos seus direitos trabalhistas. Expertise, dedicação e um histórico de resultados comprovam: sua justiça é nossa prioridade máxima.
            </motion.p>
            <motion.div 
              variants={buttonGroupVariants}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                onClick={() => window.open('https://api.whatsapp.com/send?phone=5515981100025', '_blank', 'noopener,noreferrer')}
                className="gradient-gold text-black font-semibold px-8 py-3 rounded-lg hover:shadow-gold transition-all duration-300"
                as={motion.button}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Agende Sua Consulta Gratuita
              </Button>
              <Button
                variant="outline"
                onClick={() => scrollToSection('servicos')}
                className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black px-8 py-3 rounded-lg transition-all duration-300"
                as={motion.button}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Conheça Nossas Soluções
              </Button>
            </motion.div>
          </div>

          <motion.div
            variants={imageVariants}
            whileHover="hover"
            className="relative cursor-pointer"
            onClick={() => onImageClick(newImageUrl, newImageAlt)}
          >
            <div className="relative z-10">
              <img
                className="w-full h-96 object-cover rounded-2xl shadow-2xl"
                alt={newImageAlt}
                src={newImageUrl} />
            </div>
            <div className="absolute -top-4 -right-4 w-full h-full gradient-gold rounded-2xl opacity-20"></div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;