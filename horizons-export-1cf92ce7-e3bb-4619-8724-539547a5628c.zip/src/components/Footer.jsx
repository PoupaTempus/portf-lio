import React from 'react';
import { Scale } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-black text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 gradient-gold rounded-lg flex items-center justify-center">
                <Scale className="w-6 h-6 text-black" />
              </div>
              <div>
                <span className="text-xl font-bold">Dr. João Silva</span>
                <p className="text-sm text-gray-400">Advogado Trabalhista Estrategista</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Defendendo seus direitos trabalhistas com expertise, dedicação e foco em resultados justos e satisfatórios.
            </p>
          </div>

          <div>
            <span className="font-semibold text-lg mb-4 block">Navegação Essencial</span>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="#inicio" className="hover:text-yellow-400 transition-colors">Início</a></li>
              <li><a href="#sobre" className="hover:text-yellow-400 transition-colors">Quem Somos</a></li>
              <li><a href="#servicos" className="hover:text-yellow-400 transition-colors">Nossas Soluções</a></li>
              <li><a href="#faq" className="hover:text-yellow-400 transition-colors">Perguntas Frequentes</a></li>
            </ul>
          </div>

          <div>
            <span className="font-semibold text-lg mb-4 block">Canais de Contato</span>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="tel:+5511999999999" className="hover:text-yellow-400 transition-colors">(11) 99999-9999</a> (WhatsApp Disponível)</li>
              <li><a href="mailto:contato@joaosilvaadvogado.com.br" className="hover:text-yellow-400 transition-colors break-all">contato@joaosilvaadvogado.com.br</a></li>
              <li>Av. Paulista, 1000 - Sala 1001</li>
              <li>São Paulo, SP - Coração Financeiro</li>
            </ul>
          </div>

          <div>
            <span className="font-semibold text-lg mb-4 block">Atendimento Diferenciado</span>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>Segunda a Sexta: 8h às 18h</li>
              <li>Sábado: 8h às 12h (Plantão)</li>
              <li>Domingo e Feriados: Suporte Emergencial</li>
              <li>OAB/SP: 123.456 (Consulte nossa regularidade)</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} Dr. João Silva - Advocacia Trabalhista de Excelência. Todos os direitos reservados.
            Este website observa rigorosamente as normas éticas da Ordem dos Advogados do Brasil. As informações aqui contidas não constituem promessa de resultados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;