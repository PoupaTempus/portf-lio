import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ContactSection = () => {
  const sectionVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
  };

  const itemVariants = (delay = 0) => ({
    hidden: { opacity: 0, x: -30 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.7, ease: "easeOut", delay } },
  });
  
  const infoItemVariants = (delay = 0) => ({
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut", delay } },
  });


  return (
    <section id="contato-info" className="section-padding bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Fale Conosco Agora Mesmo</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Estamos preparados para ouvir seu caso e lutar pelos seus direitos. Agende uma consulta e dê o primeiro passo.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <motion.div
            variants={itemVariants(0)}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <motion.div variants={infoItemVariants(0.2)} className="flex items-start space-x-4">
                <div className="w-12 h-12 gradient-gold rounded-lg flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-black" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Telefone Direto</p>
                  <a href="tel:+5511999999999" className="text-gray-300 hover:text-yellow-400 transition-colors">(11) 99999-9999</a>
                </div>
              </motion.div>

              <motion.div variants={infoItemVariants(0.3)} className="flex items-start space-x-4">
                <div className="w-12 h-12 gradient-gold rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-black" />
                </div>
                <div>
                  <p className="font-semibold text-lg">E-mail Profissional</p>
                  <a href="mailto:contato@joaosilvaadvogado.com.br" className="text-gray-300 hover:text-yellow-400 transition-colors break-all">contato@joaosilvaadvogado.com.br</a>
                </div>
              </motion.div>

              <motion.div variants={infoItemVariants(0.4)} className="flex items-start space-x-4">
                <div className="w-12 h-12 gradient-gold rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-black" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Nosso Escritório</p>
                  <p className="text-gray-300">Av. Paulista, 1000 - Sala 1001<br />São Paulo, SP - CEP 01310-100</p>
                </div>
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            variants={itemVariants(0.2)}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20"
          >
            <h3 className="text-2xl font-bold mb-6 text-center">Horário de Atendimento Personalizado</h3>
            <div className="space-y-3 text-gray-300 text-center">
              <motion.p variants={infoItemVariants(0.5)}>Segunda a Sexta: <span className="font-semibold">8h às 18h</span></motion.p>
              <motion.p variants={infoItemVariants(0.6)}>Sábado: <span className="font-semibold">8h às 12h</span> (Plantão)</motion.p>
              <motion.p variants={infoItemVariants(0.7)}>Domingo e Feriados: <span className="font-semibold">Atendimento Emergencial</span></motion.p>
            </div>
            <motion.div variants={infoItemVariants(0.8)}>
              <Button
                onClick={() => window.open('https://api.whatsapp.com/send?phone=5515981100025', '_blank', 'noopener,noreferrer')}
                className="w-full mt-8 gradient-gold text-black font-semibold py-3 rounded-lg hover:shadow-gold transition-all duration-300"
              >
                Contatar via WhatsApp
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;