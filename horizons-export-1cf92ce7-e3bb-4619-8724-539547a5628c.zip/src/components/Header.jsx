import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Scale, Users, Briefcase, MessageCircle, Phone } from 'lucide-react';

const iconMap = {
  Início: Scale,
  Sobre: Users,
  Serviços: Briefcase,
  FAQ: MessageCircle,
  Contato: Phone,
};

const Header = ({ menuItems }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('inicio');

  useEffect(() => {
    const handleScroll = () => {
      const sections = menuItems.filter(item => !item.isExternal).map(item => item.id);
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;

          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [menuItems]);

  const handleMenuClick = (item) => {
    if (item.isExternal) {
      window.open(item.url, '_blank', 'noopener,noreferrer');
    } else {
      const element = document.getElementById(item.id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 w-full z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <motion.div
            className="flex items-center space-x-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="w-10 h-10 gradient-gold rounded-lg flex items-center justify-center">
              <Scale className="w-6 h-6 text-black" />
            </div>
            <div>
              <span className="text-xl font-bold text-gray-900">Dr. João Silva</span>
              <p className="text-sm text-gray-600">Advocacia Trabalhista Especializada</p>
            </div>
          </motion.div>

          <nav className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => {
              const Icon = iconMap[item.label];
              return (
                <button
                  key={item.id}
                  onClick={() => handleMenuClick(item)}
                  className={`text-sm font-medium transition-colors hover:text-yellow-600 ${
                    activeSection === item.id && !item.isExternal ? 'text-yellow-600' : 'text-gray-700'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
          >
            {isMenuOpen ? <X className="w-6 h-6 text-gray-700" /> : <Menu className="w-6 h-6 text-gray-700" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-gray-200"
          >
            <div className="container mx-auto px-4 py-4">
              {menuItems.map((item) => {
                const Icon = iconMap[item.label];
                return (
                  <button
                    key={item.id}
                    onClick={() => handleMenuClick(item)}
                    className="flex items-center space-x-3 w-full py-3 text-left text-gray-700 hover:text-yellow-600 transition-colors"
                  >
                    {Icon && <Icon className="w-5 h-5" />}
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;