import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const ImageModal = ({ src, alt, onClose }) => {
  if (!src) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.5, opacity: 0 }}
          transition={{ type: "spring", stiffness: 260, damping: 20 }}
          className="relative bg-white p-2 rounded-lg shadow-2xl max-w-3xl max-h-[90vh]"
          onClick={(e) => e.stopPropagation()}
        >
          <img src={src} alt={alt} className="max-w-full max-h-[85vh] object-contain rounded" />
          <button
            onClick={onClose}
            className="absolute -top-3 -right-3 bg-yellow-500 text-black rounded-full p-2 hover:bg-yellow-600 transition-colors shadow-lg"
            aria-label="Fechar modal"
          >
            <X size={20} />
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ImageModal;