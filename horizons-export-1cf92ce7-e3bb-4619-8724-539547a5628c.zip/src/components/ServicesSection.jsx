import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Scale, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const servicesData = [
  {
    title: 'Consultoria Jurídica Estratégica',
    description: 'Análise aprofundada do seu caso, orientação precisa sobre direitos e deveres, e pareceres técnicos para embasar suas decisões.',
    icon: FileText
  },
  {
    title: 'Representação Combativa em Tribunais',
    description: 'Defesa técnica e aguerrida em todas as instâncias judiciais, desde audiências iniciais até recursos em tribunais superiores.',
    icon: Scale
  },
  {
    title: 'Negociação Habilidosa de Acordos',
    description: 'Mediação eficaz e negociação estratégica para alcançar acordos justos e vantajosos, preservando seus interesses e otimizando tempo.',
    icon: Users
  }
];

const ServicesSection = () => {
  const sectionVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.2,
        duration: 0.6,
        ease: "easeOut"
      }
    }),
    hover: { y: -5, boxShadow: "0 20px 30px -10px rgba(255, 215, 0, 0.3)" }
  };

  return (
    <section id="servicos" className="section-padding bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Soluções Jurídicas Sob Medida</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Oferecemos um portfólio completo de serviços em Direito Trabalhista, desenhados para proteger seus direitos e maximizar seus resultados.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {servicesData.map((service, index) => (
            <motion.div
              key={index}
              custom={index}
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              whileHover="hover"
              viewport={{ once: true, amount: 0.2 }}
              className="bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl shadow-lg border border-gray-100"
            >
              <motion.div 
                className="w-16 h-16 gradient-gold rounded-xl flex items-center justify-center mb-6"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: index * 0.2 + 0.4, type: "spring", stiffness: 260, damping: 20 }}
              >
                <service.icon className="w-8 h-8 text-black" />
              </motion.div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed mb-6">{service.description}</p>
              <Button
                variant="outline"
                className="w-full border-yellow-500 text-yellow-600 hover:bg-yellow-500 hover:text-black transition-all duration-300"
                onClick={() => toast({
                  title: "🚧 Este recurso ainda não foi implementado—mas não se preocupe! Você pode solicitá-lo no seu próximo prompt! 🚀"
                })}
                as={motion.button}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Descubra Mais
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;